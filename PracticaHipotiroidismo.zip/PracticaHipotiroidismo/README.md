# Aplicación del Aprendizaje Automático en la detección de pacientes con Hipotiroidismo

## Descripción del problema

## Instalación

Para generar un requirements.txt en caso de que no esté actualizado:
(multi-line imports no soportados)

```shell
pip install --user pipreqsnb
pipreqsnb JUPYTER_NOTEBOOK.ipynb
```

Para instalar todos los paquetes necesarios a partir del requirements.txt:

```shell
pip install -r requirements.txt
```

## Autores

* Pol Casacuberta Gil - [pol.casacuberta@estudiantat.upc.edu](pol.casacuberta@estudiantat.upc.edu)
* Marta Granero i Martí - [marta.granero.i@estudiantat.upc.edu](marta.granero.i@estudiantat.upc.edu)
